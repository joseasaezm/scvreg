library(modelr)

####################################################################################
####################################################################################
####################################################################################

# Function: Sample without replacement
# Arguments:
#   x: initial elements
#   n: number of elements to select from x
secureSample <- function(x,n){
  
  if(length(x) <= 1){
    return(x)
  }
  else{
    return(sample(x,n))
  }
}

####################################################################################
####################################################################################
####################################################################################

# Function: Standard cross-validation
# Arguments:
#   data_: data.frame containing the dataset
#   k_: number of folds
CV <- function(data_, k_){
  
  part_aux <- crossv_kfold(data = data_, k = k_)
  
  part <- list(train = list(NULL), test = list(NULL))
  for(i in 1:k_){
    part$test[[i]] <- part_aux$test[[i]]$idx
    part$train[[i]] <- part_aux$train[[i]]$idx
    
    if(length(part$test[[i]])+length(part$train[[i]]) != nrow(data_)){
      stop("error in CV")
      return(NULL)
    }
  }
  
  return(part)
}

####################################################################################
####################################################################################
####################################################################################

# Function: Stratified cross-validation
# Arguments:
#   data_: data.frame containing the dataset
#   k_: number of folds
#   n_: number of strata
SCVt <- function(data_, k_, ns_){
  
  idx <- sort(x = data_[,ncol(data_)], decreasing = FALSE, index.return = TRUE)$ix
  
  partID <- rep(-1, nrow(data_))
  totalFold <- rep(0,k_)
  
  stratumsize <- floor(nrow(data_)/ns_)
  totalStratum <- rep(stratumsize,ns_)
  r_ <- nrow(data_)-stratumsize*ns_
  if(r_ > 0)
    totalStratum[1:r_] <- totalStratum[1:r_] + 1
  
  iniStratum <- rep(-1,ns_)
  endStratum <- rep(-1,ns_)
  last <- 0
  for(s in 1:ns_){
    iniStratum[s] <- last+1
    endStratum[s] <- iniStratum[s]+totalStratum[s]-1
    last <- endStratum[s]
  }
  
  # divide samples per fold
  for(s in 1:ns_){
    
    sel <- idx[iniStratum[s]:endStratum[s]] # indices of the stratum
    sel <- secureSample(sel,length(sel)) # randomize indices
    
    for(i in 1:length(sel)){
      fmin <- secureSample(which(totalFold == min(totalFold)),1)
      partID[sel[i]] <- fmin
      totalFold[fmin] <- totalFold[fmin] + 1
    }

  }
  
  # error checking
  if( (sum(totalFold) != nrow(data_)) || (length(which(partID == -1)) != 0) ){
    stop("error in SCVt")
    return(NULL)
  }
  
  # build train/test partitions
  part <- list(train = list(NULL), test = list(NULL))
  for(i in 1:k_){
    part$test[[i]] <- which(partID == i)
    part$train[[i]] <- setdiff(1:nrow(data_),part$test[[i]])
    
    if(length(part$test[[i]])+length(part$train[[i]]) != nrow(data_)){
      stop("error in SCVt")
      return(NULL)
    }
  }
  
  return(part)
}

####################################################################################
####################################################################################
####################################################################################

# Function: Totally stratified cross-validation
# Arguments:
#   data_: data.frame containing the dataset
#   k_: number of folds
TSCV <- function(data_, k_){
  part <- SCVt(data_, k_, nrow(data_))
  return(part)
}

####################################################################################
####################################################################################
####################################################################################
